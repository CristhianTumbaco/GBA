<!DOCTYPE html>
<html>
	<head>
		<title>INVENTARIOS</title>
	  	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<link rel="stylesheet" href="../_lib/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="../_lib/assets/css/sty.css">
		<link rel="stylesheet" href="../_lib/assets/sweetalert/sweetalert2.min.css">
	  	<script src="../_lib/assets/sweetalert/sweetalert2.min.js"></script>
		<script src="../_lib/assets/js/jquery.min.js"></script>
	  	<script src="../_lib/assets/js/popper.min.js"></script>
	  	<script src="../_lib/assets/js/bootstrap.min.js"></script>
	</head>
	<style>

	</style>
	<body>
		<nav class="navbar navbar-expand-sm navbar-light" style="background:white;border-bottom:1px solid #3c3d47;">
	  		<a class="navbar-brand"><img class="logo" src="../_lib/assets/img/empresa.jpg"/></a>
	  		<ul class="navbar-nav">
				<li class="nav-item">
		  			<a class="nav-link" href="../Equipos/index.php">EQUIPOS</a>
				</li>
				<li class="nav-item">
		  			<a class="nav-link" href="../Asignacion/index.php">ASIGNACIÓN</a>
				</li>
				<li class="nav-item">
		  			<a class="nav-link" href="../Acta/index.php?">ACTA</a>
				</li>
				<li class="nav-item dropdown">
		  			<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
					SISTEMAS
		  			</a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="../Acta_History/index.php">Historial de Actas</a>
						<a class="dropdown-item" href="#">Reporte</a>
						<a class="dropdown-item" href="#">Venta de Equipos</a>
				  </div>
				</li>
		<!-- Dropdown -->
				<li class="nav-item dropdown">
		  			<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">MANTENIMIENTO</a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="../Personal/index.php">Personal</a>
						<a class="dropdown-item" href="../Cuentas/index.php">Cuentas</a>
						<a class="dropdown-item" href="../Departamentos/index.php">Departamentos</a>									<a class="dropdown-item" href="../Sitios/index.php">Sitios</a>	
						<a class="dropdown-item" href="../Cargos/index.php">Cargos</a>	
				  </div>
				</li>
	  		</ul>
			<a class="nav-link" style="margin-left:10%;"></a>
			<a class="nav-link" style="color: black;"> <?php echo $name; ?> </a>
			<a class="nav-link" href="../Logout/index.php" id="salir"><img style="width:20px;height:20px;" src="../_lib/assets/img/off.png"/> Salir</a>
		</nav>