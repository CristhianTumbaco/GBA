<html>
	<head>
	<link rel="stylesheet" href="../_lib/boo/css/bootstrap.min.css">	
		<style>
			header{
				width: 100%;
				height: 40px;
				border: 1px solid black;
				text-align: center;
			}
		</style>
	</head>
	<body>
		<header>
			<h3>CABECERA</h3>
		</header>
		
		