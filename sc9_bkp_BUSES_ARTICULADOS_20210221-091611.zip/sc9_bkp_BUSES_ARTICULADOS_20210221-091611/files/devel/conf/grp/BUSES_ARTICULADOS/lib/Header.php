<?php
//__NM____NM__NFUNCTION__NM__//
	if(!isset($_SESSION)){
		session_start();
	}
?>
<!doctype html>
<html>
	<head>
		<title>OPERACIONES</title>
	  	<meta charset="utf-8">
		<link rel="icon" href="../_lib/assets/img/logo.png" sizes="32x32">
	  	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	  	<link rel="stylesheet" href="../_lib/assets/css/bootstrap.min.css">					
	  	<script src="../_lib/assets/js/popper.min.js"></script>
		<script src="../_lib/assets/js/jquery.min.js"></script>	
	  	<script src="../_lib/assets/js/bootstrap.min.js"></script>
		<script src="../_lib/assets/js/sweetalert2.js"></script>
		<link href="../_lib/assets/excel/css/tableexport.css" rel="stylesheet" type="text/css">		
		<link href="../_lib/assets/css/dataTables.bootstrap4.min.css" rel="stylesheet"/>
		<script src="../_lib/assets/js/jquery.dataTables.min.js"></script>
		<script src="../_lib/assets/js/dataTables.bootstrap4.min.js"></script>
		<link href="../_lib/assets/css/rowGroup.dataTables.min.css" rel="stylesheet">
		<script src="../_lib/assets/js/select2.min.js"></script>
		<link rel="stylesheet" href="../_lib/assets/css/select2.min.css">
		<link rel="stylesheet" href="../_lib/assets/css/select2-bootstrap4.min.css">		
		<link rel="stylesheet" href="../_lib/assets/fontawesome/css/all.css">
		<link rel="stylesheet" href="../_lib/assets/css/jquery.toast.css">
		<script src="../_lib/assets/js/jquery.toast.js"></script>	
		<link rel="stylesheet" href="../_lib/assets/css/sty.css">
		
		<script>
			$(document).ready(function(){
				var table = $('.tablas').DataTable({
					"paging":   false, //Turn off paging, all records on one page
					"ordering": true, //Turn off ordering of records
					"info":     false,
					"searching": false,
					"language": {
						"sProcessing":     "Procesando...",
						"sLengthMenu":     "Mostrar _MENU_ registros",
						"sZeroRecords":    "No se encontraron resultados",
						"sEmptyTable":     "No hay datos",
						"sInfo":           "_START_ al _END_ de _TOTAL_ registros",
						"sInfoEmpty":      "0",
						"sInfoFiltered":   "(total _MAX_ )",
						"sInfoPostFix":    "",
						"sSearch":         "Buscar:",
						"sUrl":            "",
						"sInfoThousands":  ",",
						"sLoadingRecords": "Cargando...",
						"oPaginate": {
							"sFirst":    "Primero",
							"sLast":     "Último",
							"sNext":     "Siguiente",
							"sPrevious": "Anterior"
						}
					},
					"dom":"<'row'<'col-sm-12 col-md-2'f><'col-sm-12 col-md-4'><'col-sm-12 col-md-6'l>>" +
"<'row'<'col-sm-12'tr>>" +
"<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>"
				});	
			});
		</script>
	</head>
	<body>
		<nav class="navbar navbar-expand-lg navbar-light border-bottom box-shadow">
			<a class="navbar-brand" href="../Administrador/index.php"><i class="fas fa-bus-alt" style="font-size: 50px;color: #007bff;"></i></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarText">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="../Administrador/index.php"><i class="fas fa-home"></i> MENÚ</a>
					</li>					
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
							<i class="fas fa-calendar-alt"></i> PROGRAMACIÓN
						</a>
						<div class="dropdown-menu">
							<?php if(isset($_SESSION['rol']) && $_SESSION['rol']!=null && $_SESSION['rol']==1 || $_SESSION['rol']==2){ ?>
							<a class="dropdown-item" href="../PMensual/index.php"><i class="fas fa-calendar-week"></i> Mensual</a>
							<?php } ?>
							<a class="dropdown-item" href="../PDiaria/index.php"><i class="fas fa-calendar-day"></i> Diaria</a>
						 </div>
					</li>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
							<i class="fas fa-business-time"></i> OPERACIONES
						</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="../GraficoMarcha/index.php"><i class="fas fa-chart-pie"></i> Grafico de Marcha</a>
							<?php if(isset($_SESSION['rol']) && $_SESSION['rol']!=null && $_SESSION['rol']==1 || $_SESSION['rol']==2){ ?>
							<a class="dropdown-item" href="../Conductor/index.php"><i class="fas fa-user-tie"></i> Conductores</a>
							<?php } ?>
							<a class="dropdown-item" href="../CodConductores/index.php"><i class="far fa-window-restore"></i> Códigos de Conductores</a>
							<?php if(isset($_SESSION['rol']) && $_SESSION['rol']!=null && $_SESSION['rol']==1 || $_SESSION['rol']==2){ ?>
							<a class="dropdown-item" href="../Bus/index.php"><i class="fas fa-bus"></i> Buses</a>
							<?php } ?>
<!-- 							<a class="dropdown-item" href="../Asignacion/index.php"><i class="fas fa-network-wired"></i> Asignaciones</a> -->
							
						 </div>
					</li>
					<?php if(isset($_SESSION['rol']) && $_SESSION['rol']!=null && $_SESSION['rol']==1){ ?>
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"><i class="fas fa-cogs"></i> MANTENIMIENTO</a>
						<div class="dropdown-menu">
							<a class="dropdown-item" href="../Personal/index.php"><i class="fas fa-user"></i> Personal</a>
							<a class="dropdown-item" href="../Cuentas/index.php"><i class="fas fa-user-shield"></i> Cuentas</a>	
							<a class="dropdown-item" href="../Parametros/index.php"><i class="fas fa-tools"></i> Parametros</a>	
<!-- 							<a class="dropdown-item" href="../VConsulta/index.php"><i class="fas fa-tv"></i> Vista Consulta</a>	 -->
					  </div>
					</li>
					<?php } ?>
				</ul>
				<span class="navbar-text">			
					<ul class="navbar-nav mr-auto">
						<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown"><i class="far fa-user"></i> </a>
							<div class="dropdown-menu dropdown-menu-right">
								<a class="dropdown-item"><?php echo $name;?></a>
								<a class="dropdown-item salir" href="../Logout/index.php"><i class="fas fa-sign-out-alt"></i> Salir</a>			
						  </div>
						</li>
					</ul>
				</span>
			</div>
		</nav>
			<div>
				<?php if(isset($_SESSION['delete'])){ 
						echo "<script>$.toast({
						heading: 'LISTO',
						text: 'Registros Eliminados',
						showHideTransition: 'slide',
						icon: 'success',
						position: 'bottom-right'
						})</script>";		
				 	} 
					unset($_SESSION['delete']);
				?>
			</div>
			<div>
				<?php if(isset($_SESSION['error'])){ 
						echo "<script>$.toast({
						heading: 'Se ha producido un error',
						text: 'No se pudo cargar los datos, verifique que sean tipo HORA',
						showHideTransition: 'slide',
						icon: 'error',
						hideAfter: 8000,
						position: 'bottom-right'
						})</script>";		
				 	} 
					unset($_SESSION['error']);
				?>
			</div>
			<div>
				<?php if(isset($_SESSION['duplicado'])){ 
						echo "<script>$.toast({
						heading: 'Duplicado',
						text: 'Ya esta registrado ese usuario',
						showHideTransition: 'slide',
						icon: 'warning',
						position: 'bottom-right'
						})</script>";		
				 	} 
					unset($_SESSION['duplicado']);
				?>
			</div>
			<div>
				<?php if(isset($_SESSION['save'])){ 
						echo "<script>$.toast({
						heading: 'LISTO',
						text: 'Registro Almacenado',
						showHideTransition: 'slide',
						icon: 'success',
						position: 'bottom-right'
						})</script>";		
				 	} 
					unset($_SESSION['save']);
				?>
			</div>
			<div>
				<?php if(isset($_SESSION['error_s'])){ 
						echo "<script>$.toast({
						heading: 'Error de Sistema',
						text: 'Se ha producido un error inesperado',
						showHideTransition: 'slide',
						icon: 'error',
						position: 'bottom-right'
						})</script>";		
				 	} 
					unset($_SESSION['error_s']);
				?>
			</div>
		
		
<?php		  
?>